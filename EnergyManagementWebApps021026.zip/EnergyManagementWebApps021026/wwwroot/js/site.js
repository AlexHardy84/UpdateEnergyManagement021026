﻿//function setZoomLevel() {
//    document.body.style.zoom = "67%";
//}

//window.addEventListener("load", setZoomLevel);
